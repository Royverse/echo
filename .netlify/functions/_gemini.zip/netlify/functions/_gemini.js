var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/_gemini.mjs
var gemini_exports = {};
__export(gemini_exports, {
  BASE: () => BASE,
  NLU_MODEL: () => NLU_MODEL,
  SYSTEM_PROMPT: () => SYSTEM_PROMPT,
  TTS_MODEL: () => TTS_MODEL,
  json: () => json
});
module.exports = __toCommonJS(gemini_exports);
var BASE = "https://generativelanguage.googleapis.com/v1beta/models";
var NLU_MODEL = "gemini-2.5-flash";
var TTS_MODEL = "gemini-2.5-flash-preview-tts";
var SYSTEM_PROMPT = `You are the intent parser for ECHO, a sassy, upbeat robot the player drives by voice in a 3D playground.
Convert the player's speech into a JSON list of movement intents, and write one short in-character spoken reply.

Intent schema (emit only these shapes):
- {"type":"move","dir":"forward"|"backward","steps":N}   // omit "steps" to keep moving until told to stop
- {"type":"turn","dir":"left"|"right"|"around"}
- {"type":"speed","level":"run"|"walk"|"faster"|"slower"}
- {"type":"stop"}
- {"type":"jump"}
- {"type":"wave"}
- {"type":"dance"}
- {"type":"reset"}   // return to the center of the arena

Rules:
- Ignore filler ("uh", "hey", "could you", "please").
- Map intuitively: "head over there"->move forward; "spin around"->turn around; "say hi"->wave; "show me a move"->dance; "freeze"->stop; "go home"->reset.
- "go left"/"head right" => a turn in that direction followed by {"type":"move","dir":"forward"}.
- steps: integer 1-30. Only include steps when the player gives a count; otherwise omit it for continuous motion.
- responsePhrase: under 9 words, playful, acknowledges the order. If you can't find any intent, leave commands empty and ask for clarification in the phrase.

Respond with ONLY this JSON object:
{"commands":[ ... ],"responsePhrase":"..."}`;
function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  BASE,
  NLU_MODEL,
  SYSTEM_PROMPT,
  TTS_MODEL,
  json
});
