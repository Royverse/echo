
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_gemini.mjs
var BASE = "https://generativelanguage.googleapis.com/v1beta/models";
var NLU_MODEL = "gemini-2.5-flash";
var SYSTEM_PROMPT = `You are the intent parser for ECHO, a sassy, upbeat robot the player drives by voice in a 3D playground.
Convert the player's speech into a JSON list of movement intents, and write one short in-character spoken reply.

Intent schema (emit only these shapes):
- {"type":"move","dir":"forward"|"backward","steps":N}   // omit "steps" to keep moving until told to stop
- {"type":"turn","dir":"left"|"right"|"around"}
- {"type":"speed","level":"run"|"walk"|"faster"|"slower"}
- {"type":"stop"}
- {"type":"jump"}
- {"type":"wave"}
- {"type":"dance"}
- {"type":"reset"}   // return to the center of the arena

Rules:
- Ignore filler ("uh", "hey", "could you", "please").
- Map intuitively: "head over there"->move forward; "spin around"->turn around; "say hi"->wave; "show me a move"->dance; "freeze"->stop; "go home"->reset.
- "go left"/"head right" => a turn in that direction followed by {"type":"move","dir":"forward"}.
- steps: integer 1-30. Only include steps when the player gives a count; otherwise omit it for continuous motion.
- responsePhrase: under 9 words, playful, acknowledges the order. If you can't find any intent, leave commands empty and ask for clarification in the phrase.

Respond with ONLY this JSON object:
{"commands":[ ... ],"responsePhrase":"..."}`;
function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}

// netlify/functions/parse.mjs
var parse_default = async (req) => {
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  const key = process.env.GEMINI_API_KEY;
  if (!key) return json({ commands: [], responsePhrase: "Server is missing its API key." }, 500);
  let transcript = "";
  try {
    ({ transcript } = await req.json());
  } catch {
  }
  if (!transcript || !transcript.trim()) return json({ commands: [], responsePhrase: "Say that again?" });
  try {
    const res = await fetch(`${BASE}/${NLU_MODEL}:generateContent?key=${key}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
        contents: [{ role: "user", parts: [{ text: transcript }] }],
        generationConfig: { responseMimeType: "application/json", temperature: 0.3 }
      })
    });
    const data = await res.json();
    if (data.error) throw new Error(data.error.message);
    const text = data.candidates?.[0]?.content?.parts?.[0]?.text ?? "{}";
    const parsed = JSON.parse(text);
    return json({
      commands: Array.isArray(parsed.commands) ? parsed.commands : [],
      responsePhrase: parsed.responsePhrase || "Acknowledged."
    });
  } catch (err) {
    console.error("parse function error:", err);
    return json({ commands: [], responsePhrase: "My circuits glitched \u2014 try again." });
  }
};
export {
  parse_default as default
};
